<form method='GET'>
  <div class='choices-container'>
    <div class='choice' id='choice1'>
      <div class='thumb'>
        <img src='public/images/quest01.png' alt=''>
      </div>
      <div>
        <input type='submit' name='choice' value='raetsel1' id='btn1'>
      </div>
    </div>
    <div class='choice' id='choice2'>
      <div class='thumb'>
        <img src='public/images/quest02.png' alt=''>
      </div>
      <div>
        <input type='submit' name='choice' value='raetsel2' id='btn2'>
      </div>
    </div>  
    <div class='choice' id='choice3'>
      <div class='thumb'>
        <img src='public/images/quest03.png' alt=''>
      </div>
      <div>
        <input type='submit' name='choice' value='raetsel3' id='btn3'>
      </div>  
    </div>
  </div>
</form>